/***
*winputs.c - wscanf style input from a FILE with size
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*
*******************************************************************************/


#ifndef _UNICODE
#define _UNICODE 1
#endif  /* _UNICODE */

#ifndef UNICODE
#define UNICODE 1
#endif  /* UNICODE */

#define _SECURE_SCANF
#include "input.c"

