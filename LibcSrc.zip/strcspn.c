/***
*strcspn.c - Defines the strcspn function.
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       The function strcspn is mostly common code with strspn in strspn.c.
*
*******************************************************************************/

#define SSTRCSPN
#include "strspn.c"
