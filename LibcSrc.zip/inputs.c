/***
*inputs.c - formatted input with size used by scanf_s etc
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*******************************************************************************/


#define _SECURE_SCANF
#include "input.c"

