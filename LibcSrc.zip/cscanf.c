/***
*cscanf.c - Conio version of scanf
*
*       Copyright (c) Microsoft Corporation.  All rights reserved.
*
*Purpose:
*       Perform formatted i/o directly to the keyboard.
*
*******************************************************************************/

#define CPRFLAG 1
#include "input.c"
