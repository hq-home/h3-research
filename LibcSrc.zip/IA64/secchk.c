/***
*secchk.c - checks buffer overrun security cookie for IA64
*
*       Copyright (c) Microsoft Corporation.  All rights reserved.
*
*Purpose:
*       Defines compiler helper __security_check_cookie, used by the /GS
*       compile switch to detect local buffer variable overrun bugs/attacks.
*
*       When compiling /GS, the compiler injects code to detect when a local
*       array variable has been overwritten, potentially overwriting other
*       variables on the stack.  A local variable is at the high end of the
*       local stack frame and initialized on entering the function.  When
*       exiting the function, the compiler inserts code to verify that the
*       local variable has not been modified.  If it has, then an error
*       reporting routine is called.
*
*******************************************************************************/

#include <windows.h>
#include <process.h>

/*
 * The global security cookie.  This name is known to the compiler.
 */
extern UINT_PTR __security_cookie;

/***
*__security_check_cookie(cookie) - check for buffer overrun
*
*Purpose:
*       Compiler helper.  Check if a local copy of the security cookie still
*       matches the global value.  If not, then report the fatal error.
*
*       The actual reporting is done by __report_gsfailure.
*
*Entry:
*       UINT_PTR cookie - local security cookie to check
*
*Exit:
*       Returns immediately if the local cookie matches the global version.
*       Otherwise, calls the failure reporting handler and exits.
*
*Exceptions:
*
*******************************************************************************/

void __security_check_cookie(UINT_PTR cookie)
{
    /* Immediately return if the local cookie is OK. */
    if (cookie == __security_cookie && (cookie & 0xFFFF000000000000i64) == 0)
    {
        return;
    }

    /* Report the failure */
    __report_gsfailure(cookie);
}
