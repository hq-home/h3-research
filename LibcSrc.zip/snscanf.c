/***
*snscanf.c - read formatted data from string of given length
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       defines snscanf() - reads formatted data from string of given length
*
*******************************************************************************/
#define _SNSCANF
#include "sscanf.c"
