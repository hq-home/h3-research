/***
*cprintf.c - Conio version of printf
*
*       Copyright (c) Microsoft Corporation.  All rights reserved.
*
*Purpose:
*       Perform formatted i/o directly to the console.
*
*******************************************************************************/

#define CPRFLAG 1
#include "output.c"
